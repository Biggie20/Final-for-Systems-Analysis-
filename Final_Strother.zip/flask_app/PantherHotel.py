
from flask import Flask, redirect, url_for, request
app = Flask(__name__)

@app.route('/')
def Panther_Hotel():
	return render_template("Reservation.html")

	@app.route('/success/<name>')
	def success(name):
		return 'Welcome to the Panther Hotel %s' % name

		@app.route('/Reservation', methods = ['POST', 'GET'])
		def Reservation():
			if request.method == 'POST':
				user = request.form('nm')
				return redirect(url_for('success', name = user))

				@app.route('/Reservation', methods = ['POST','GET'])
				def Reservation():
					if request.method == 'POST':
						user = request.form('date')
						return redirect(url_for('success', name = user))

						@app.route('/Reservation', methods = ['POST', 'GET'])
						def Reservation():
							if request.method == 'POST':
								user = request.form('odate')
								return redirect(url_for('success', name = user))
							
							@app.route('/Reservation', methods = ['POST', 'GET'])
							def Reservation():
								if request.method == 'POST':
									user = request.form('RT')
									return redirect(url_for('success', name = user))
									




if __name__ == "__main__":
	app.run(debug =True)
