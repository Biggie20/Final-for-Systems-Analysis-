# description of this project
The Panther Hotel is a five-star housing/dining experience. The Panther Hotel is now providing a way for visitors to fill out room applications online. All you have to do to book a room is click on the book a room tab, and then fill out basic information, like your name, check-in and check-out dates, and what type of room you would like. Then you will get a notification from our staff stating that you have recieved said room for however many nights that you selected. 

```python 
class Reservatioin():
    def __init__(Name, CheckInDate, CheckOutDate, RoomType):
        self.name = name
        self.CheckInDate = CheckInDate
        self.CheckOutDate = CheckOutDate